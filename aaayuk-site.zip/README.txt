윻 - 미연시 웹사이트 (정적 사이트)

구성
- index.html : 첫 화면
- style.css  : 디자인
- script.js  : 스토리와 게임 기능
- images/    : 배경 이미지 12장

배포
빌드 없이 폴더 전체를 그대로 올리면 됩니다 (Netlify, Vercel, GitHub Pages, Cloudflare Pages 등).
index.html 이 사이트의 루트에 오도록 올려 주세요.
진행 상황 저장은 방문자 브라우저의 localStorage에 저장됩니다.
